
/* ************************************************************************** */
/*                                                                            */
/*                                                        &&&&&&&&&&          */
/*           Earth_Guardians.js                        &&&&&&&& &&&&&&&       */
/*                                                   &&&&&&        &&&&&&     */
/*                                                  &&&&&            &&&&&    */
/*   By: Hamdan Manea     <H00467604@hct.ac.ae>    &&&&&              &&&&&   */
/*   By: Abdullah Almurri <H00412977@hct.ac.ae>    &&&&                &&&&   */
/*   By: Mohamed Altamimi <H00355162@hct.ac.ae>   &&&&&                &&&&   */
/*                                                &&&&&                &&&&   */
/*   Created: 2023/01/28 17:50:56 by Mohamed O    &&&&&&&&&&&&&&&&&&&& &&&&   */
/*                                                &&&&&&&&&&&&&&&&&&&& &&&&   */
/*                                                                            */
/* ************************************************************************** */

// player status and the game status
var stillAlive = true;
var coin = 0;
var coinX = 0;
var coinY = 0;
var coinAmount = 0;
var coinRound = 0;
var minutes;
var seconds;
var timeString;
var Time = 0;
var wave = 1;

//Declare Canvas Width and Height additional to Delay
var canvasW = 600;
var canvasH = 550;
var delay = 70;

// Background attribute
var background = new Image();
background.src = "images/spaceBackground.png";
var bgx = 0;
var bgy = 0;
var moveBg = 3; //Background speed
var bgstatus = false;
var bgw = 1500;
var bgh = 550;

//Meteor locations with (flag = ID) ** 22.5 is the meteor width and height / 2
var locations = [
  { flag: 1, locX: -(canvasW / 10),                  locY: -(canvasH / 10) },
  { flag: 2, locX: canvasW / 2 - 22.5,                locY: -(canvasH / 10) },
  { flag: 3, locX: canvasW + (canvasW / 10) - 22.5,  locY: -(canvasH / 10) - 22.5 },
  { flag: 4, locX: canvasW + (canvasW / 10),         locY: canvasH / 2 - 22.5 },
  { flag: 5, locX: canvasW + (canvasW / 10),         locY: canvasH + (canvasH / 10) },
  { flag: 6, locX: canvasW / 2 - 22.5,                locY: canvasH + (canvasH / 10) },
  { flag: 7, locX: -(canvasW / 10) - 22.5,           locY: canvasH + (canvasH / 10) - 22.5 },
  { flag: 8, locX: -(canvasW / 10),                  locY: canvasH / 2 - 22.5 },
];

// ##################################################### meteor 0
// can generate random place for the meteor and create multiable meteors
var numMeteor = 3; //Each wave
var PrevNumMeteor = numMeteor;
var ArrMeteor = [];
var MeteorRandomIndex;
var MeteorPrevioIndex = -1;
var meteor = {
  image: new Image(),
  imageW: 44.75,
  imageH: 44.75,
  w: 44.75,
  h: 44.75,
  x: canvasW / 2 - 128 / 2,
  y: canvasH / 2 - 128 / 2,
  currentFrameX: 0,
  currentFrameY: 0,
  totalFramesX: 8,
  totalFramesY: 4,
  damage: 25,
  flag: 0,
  speedX: canvasW / 100, // == 6
  speedY: canvasH / 100, // == 5.5
  allowToMove: 3,
};

// ##################################################### fireball 1
// Fireball Attribute
var numFireball = 3;
var fireball = {
  image: new Image(),
  imageW: 24.5,
  imageH: 25,
  w: 24.5,
  h: 25,
  x: canvasW / 2 - 24.5 / 2,
  y: canvasH / 2 - 25 / 2,
  currentFrameX: 0,
  currentFrameY: 0,
  totalFramesX: 5,
  totalFramesY: 1,
  unitNum: 4,
  speedX: canvasW / 100, // == 6
  speedY: canvasH / 100, // == 5.5
  allowToMove: false,
  hit: false
};

// ################################################### Earth and lifebar
var lifePercentage = 100; // amount in the health bar
var maxLifeWidth = 100; // maximum life bar upgrade
var earth = {
  image: new Image(),
  imageW: 90,
  imageH: 90,
  w: 90,
  h: 90,
  x: canvasW / 2 - 90 / 2,
  y: canvasH / 2 - 90 / 2,
  currentFrameX: 0,
  currentFrameY: 0,
  totalFramesX: 5,
  totalFramesY: 6,
  health: 25,
  curHealth: 50,
};

// ################################################  explosion attribut
var ArrExplosion = [];
//Explosion sound
var explode = new Audio("sounds/explosion.mp3");
explode.load();
var explosionRound = 0;
var explosion = {
  image: new Image(),
  imageW: 41.6,
  imageH: 42,
  w: 41.6,
  h: 42,
  x: 400,
  y: 400,
  currentFrameX: 0,
  currentFrameY: 0,
  totalFramesX: 6,
  totalFramesY: 1,
  status: false,
};

//Shield images atttributes
var shield = {
  image: new Image(),
  w: 45,
  h: 45,
  x: canvasW / 2 - 45 / 2,
  y: canvasH / 2 - earth.h,
  speed: 1
};

//Assigning the varibales to the resources images
meteor.image.src = "images/meteor.png";
fireball.image.src = "images/fireball.png";
earth.image.src = "images/earth.png";
explosion.image.src = "images/exeplotion.png";
shield.image.src = "images/shield.png";